# php.porttable.debug

#### 介绍

PHP代码本地调试工具，版本号为5.2.17，可作为CTF web辅助工具，例如php反序列化

注意：编辑框组建依赖webview2

#### 下载

参考release文件，也可下载aardio手动编译

#### 编译

使用webstorm（推荐）打开web.src目录

npm install 下载依赖包

npm build 执行webpack打包输出到web目录

aardio IDE打开项目

#### 软件截图

![image](https://github.com/sfantree/php.porttable.debug/blob/master/img/1.jpg)

