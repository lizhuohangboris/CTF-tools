1. npm install 下载依赖包
2. npm build 执行webpack打包 输出到web目录