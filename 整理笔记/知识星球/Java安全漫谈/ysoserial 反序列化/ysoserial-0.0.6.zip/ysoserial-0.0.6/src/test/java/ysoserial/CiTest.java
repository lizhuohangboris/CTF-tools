package ysoserial;

import org.junit.Test;

public class CiTest {
    @Test
    public void test() {
        System.out.println("System.getProperties(): " + System.getProperties());
        System.out.println("System.getenv(): " + System.getenv());
    }
}
