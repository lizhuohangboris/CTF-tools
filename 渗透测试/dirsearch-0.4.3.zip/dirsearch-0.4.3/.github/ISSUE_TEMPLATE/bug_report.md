---
name: Bug Report
about: Report a dirsearch problem
labels: bug
---

### What is the current behavior?

What actually happens?

### What is the expected behavior?

What it should be instead?

### Any additional information?

Screenshots, dirsearch log, dirsearch version, used command, ...?
